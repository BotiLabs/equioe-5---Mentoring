import { Component, ViewChild } from '@angular/core';
import { NavController, ToastController, App, Content, ModalController } from 'ionic-angular';
import { ListMentorPage } from '../list-mentor/list-mentor';
import { MentoredProvider } from '../../providers/mentored/mentored';
import { SchedulePage } from '../schedule/schedule';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  schedule: boolean = false;
  mentor = [];
  @ViewChild(Content) content: Content;

  constructor(public navCtrl: NavController,
    public toastCtrl: ToastController,
    public appCtrl: App,
    public mentoredProvider: MentoredProvider,
    public modalCtrl: ModalController) {

  }

  ngOnInit() {
    this.mentoredProvider.getTruckerStorage().subscribe(r => {
      let i: any = r;
      let m = JSON.parse(i._body)
      for (let mentors of m) {
        if (mentors.mentor == true) {
          this.mentor.push(mentors);
          console.log(this.mentor)
          continue
        }
      }
    })
  }

  presentProfileModal() {
    this.navCtrl.push(SchedulePage);
  }

  like() {
    this.schedule = !this.schedule;
  }

  presentToast() {
    const toast = this.toastCtrl.create({
      message: 'Solicitação efetuada, aguarde a confirmação!',
      duration: 3000
    });
    toast.present();

    this.mentor.shift()
    this.content.scrollToTop(400);
    this.like();
  }

  likeToast() {
    const toast = this.toastCtrl.create({
      message: 'Solicitação efetuada, aguarde a confirmação!',
      duration: 3000
    });
    toast.present();

  }

  nextMentor() {
    this.navCtrl.push(ListMentorPage);
  }

  unlike(){
    this.mentor.shift()
  }
}
