import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { MentoredProvider } from '../../providers/mentored/mentored';
import { FeedbackPage } from '../feedback/feedback';

/**
 * Generated class for the SchedulePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-schedule',
  templateUrl: 'schedule.html',
})
export class SchedulePage {
  mentor = [];

  constructor(public navCtrl: NavController,
    public toastCtrl: ToastController,
    public navParams: NavParams,
    public mentoredProvider: MentoredProvider) {
    this.mentoredProvider.getTruckerStorage().subscribe(r => {
      let i: any = r;
      let m = JSON.parse(i._body)
      for (let mentors of m) {
        if (mentors.mentor == false) {
          this.mentor.push(mentors);
          console.log(this.mentor)
          continue
        }
      }
    })
  }

  ngOnInit() {

  }

  presentToast() {
    const toast = this.toastCtrl.create({
      message: 'Confirmado agendamento!',
      duration: 3000
    });
    toast.present();

    this.mentor.shift()
  }

  cancelToast() {
    const toast = this.toastCtrl.create({
      message: 'Cancelado agendamento!',
      duration: 3000
    });
    toast.present();

    this.mentor.shift()
    console.log(this.mentor)
  }

  presentProfileModal() {
    this.navCtrl.push(FeedbackPage);
  }


}
