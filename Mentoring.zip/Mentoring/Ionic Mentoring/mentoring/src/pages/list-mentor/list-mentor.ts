import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { MentoredProvider } from '../../providers/mentored/mentored';

/**
 * Generated class for the ListMentorPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-list-mentor',
  templateUrl: 'list-mentor.html',
})
export class ListMentorPage {
  mentor = [];

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public toastCtrl: ToastController,
    public mentoredProvider: MentoredProvider) {
    this.mentoredProvider.getTruckerStorage().subscribe(r => {
      let i: any = r;
      let m = JSON.parse(i._body)
      for (let mentors of m) {
        if (mentors.mentor == true) {
          this.mentor.push(mentors);
          console.log(this.mentor)
          continue
        }
      }
    })
  }

  ngOnInit() {

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ListMentorPage');
  }

  unlike(){
    this.mentor.shift()
  }

  cancelToast() {
    const toast = this.toastCtrl.create({
      message: 'Cancelado agendamento!',
      duration: 3000
    });
    toast.present();

    this.mentor.shift()
    console.log(this.mentor)
  }

  likeToast() {
    const toast = this.toastCtrl.create({
      message: 'Agendamento feito com sucesso!',
      duration: 3000
    });
    toast.present();

    this.mentor.shift()
    console.log(this.mentor)
  }

}
