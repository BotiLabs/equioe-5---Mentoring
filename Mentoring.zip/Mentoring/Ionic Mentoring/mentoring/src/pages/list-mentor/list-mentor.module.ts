import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListMentorPage } from './list-mentor';

@NgModule({
  declarations: [
    ListMentorPage,
  ],
  imports: [
    IonicPageModule.forChild(ListMentorPage),
  ],
})
export class ListMentorPageModule {


  
}
