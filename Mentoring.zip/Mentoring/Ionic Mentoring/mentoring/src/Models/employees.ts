export class searchEmplyeesModel {

    register: string;
    name: string;
    mentor: boolean;
    boticoin: number;

    constructor() {
        this.name = "";
        this.register = "";
    }
}