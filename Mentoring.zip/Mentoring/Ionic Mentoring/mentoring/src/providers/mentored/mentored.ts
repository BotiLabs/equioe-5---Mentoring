import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { searchEmplyeesModel } from '../../Models/employees'
import 'rxjs/add/operator/map';
/*
  Generated class for the MentoredProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class MentoredProvider {

  private baseApiPath = "http://localhost:3000/api";

  constructor(public http: Http) {
    // console.log('Hello MentoredProvider Provider');
  }

  postTruckerStorage(employee: searchEmplyeesModel){
    return this.http.post(this.baseApiPath + "/employees", employee);
  }

  getTruckerStorage(){
    return this.http.get(this.baseApiPath + "/employees");
  }

  searchTruckerStorageByDate(request) {
    let query: string = `${this.baseApiPath}/employees`;
    return this.http.post(query, JSON.stringify(request))
      .map((res) => res.json());
  }

}
