import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ListMentorPage } from '../pages/list-mentor/list-mentor';
import { MentoredProvider } from '../providers/mentored/mentored';
import { Http, HttpModule } from '@angular/http';
import { SchedulePage } from '../pages/schedule/schedule';
import { FeedbackPage } from '../pages/feedback/feedback';
import { ViewFeedbackPage } from '../pages/view-feedback/view-feedback';

@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    ListMentorPage,
    SchedulePage,
    FeedbackPage,
    ViewFeedbackPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    ListMentorPage,
    SchedulePage,
    FeedbackPage,
    ViewFeedbackPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    MentoredProvider,
    SchedulePage,
    FeedbackPage,
    ViewFeedbackPage
  ]
})
export class AppModule {}
