module.exports = {
	production: false,
    mongodb: {
        uri: 'mongodb://<dbuser>:<dbpassword>@ds045107.mlab.com:45107/hackmentoring',
        options: {
            user: 'mentoringadmin',
            pass: 'mentoringadmin123',
            useMongoClient: true
        }
    }
};