
'use strict';
const mongoose = require('mongoose');
const Model = require('../models/training'),
	Training = Model.Training,
	ObjectId = require('mongoose').Types.ObjectId;


exports.get = async (query) => {

	if (!query)
		query = {};

		const res = await Training.find(query).sort({ 'name': 1 });
	return res;
}

exports.getById = async (id) => {
	const res = await Training.findById(id);
	return res;
}

exports.create = async (usuario) => {

	let obj = new Training(usuario);
	return await obj.save();
}

exports.update = async (id, training) => {

	return Training.findByIdAndUpdate(id, {
		$set: {
			whoWish: training.whoWish,
            mentor: training.mentor,
            accepted: training.accepted,
            reason: training.reason,
		}
	});
}

exports.delete = async (id) => {
	return await Training.findByIdAndRemove(id);
}

exports.count = async (query) => {
	return await Training.count(query);
}