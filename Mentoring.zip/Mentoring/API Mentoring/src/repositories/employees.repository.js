
'use strict';
const mongoose = require('mongoose');
const Model = require('../models/employees'),
	Employees = Model.Employees,
	ObjectId = require('mongoose').Types.ObjectId;


exports.get = async (query) => {

	if (!query)
		query = {};

		const res = await Employees.find(query).sort({ 'name': 1 });
	return res;
}

exports.getById = async (id) => {
	const res = await Employees.findById(id);
	console.log(res)
	return res;
}

exports.create = async (usuario) => {

	let obj = new Employees(usuario);
	return await obj.save();
}

exports.update = async (id, employees) => {

	return Employees.findByIdAndUpdate(id, {
		$set: {
			name: employees.name,
			mentor: employees.mentor,
			skills: employees.skills,
			scheduled: employees.scheduled,
		}
	});
}

exports.delete = async (id) => {
	return await Employees.findByIdAndRemove(id);
}

exports.count = async (query) => {
	return await Employees.count(query);
}

exports.updateSchedule = async (id, employees) => {

	return Employees.findByIdAndUpdate(id, {
		$set: {
			scheduled: employees.scheduled,
		}
	});
}