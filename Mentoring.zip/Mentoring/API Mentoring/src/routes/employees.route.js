'use strict';

let controller = require('../controllers/employees.controller');

module.exports = (app) => {
    app.route('/api/employees')
        .post(controller.create)
        .get(controller.getAll);

        app.route('/api/employees/:id')
        .get(controller.getById)
        .put(controller.update)
        .delete(controller.delete);

        app.route('/api/mentor/:id')
        .post(controller.getMentorByMentor)
}