'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const schema = new Schema({
    register: {
        type: String,
        trim: true
    },
    name: {
        type: String,
        trim: true
    },
    mentor: {
        type: Boolean,
    },
    skills: {
        type: []
    },
    createDate: {
        type: Date,
        default: Date.now
    },
    boticoin: {
        type: Number,
    },
    scheduled: {
        type: Boolean,
        default: false
    }
});

module.exports.Employees = mongoose.model('employees', schema, 'employee');