'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const schema = new Schema({
    whoWish: {
        type: String,
    },
    mentor: {
        type: String,
        trim: true
    },
    accepted: {
        type: Boolean,
        default: null
    },
    reason: {
        type: String
    }
});

module.exports.Training = mongoose.model('training', schema, 'train');