'use strict';
const Model = require('../models/employees'),
    Employees = Model.Employees,
    Repository = require("../repositories/employees.repository");;


exports.getAll = async (req, res) => {

    try {
        var data = await Repository.get();

        res.status(200).json(data);

    } catch (err) {
        res.status(500).send({
            message: 'Falha ao processar aquisição',
            err
        });
    }
}

exports.getById = async (req, res) => {
    try {
        var employees = await Repository.getById(req.params.id);
        if (employees)
            res.status(200).json({
                _id: employees._id,
                register: employees.register,
                name: employees.name,
                mentor: employees.mentor,
                skills: employees.skills,
                createDate: employees.createDate,
                boticoin: employees.boticoin
            });
        else
            res.status(200).send("Nenhum mentor foi localizado");

    } catch (err) {
        res.status(500).send("Erro ao tentar obter consultor por id");
    }
}

exports.create = async (req, res) => {
    try {

        let newEmployees = {
            register: req.body.register,
            name: req.body.name,
            mentor: req.body.mentor,
            skills: req.body.skills,
        };

        var employees = await Repository.create(newEmployees);

        res.status(200).json(employees);

    } catch (err) {
        res.status(500).send(err);
    }
}

exports.update = async (req, res) => {
    try {
        await Repository.update(
            req.params.id, {
                name: req.body.name,
                mentor: req.body.mentor,
                skills: req.body.skills,
            });

        var employees = await Repository.getById(req.params.id);

        res.status(200).json({
            register: employees.register,
            name: employees.name,
            mentor: employees.mentor,
            skills: employees.skills,
            boticoin: employees.boticoin
        });
    } catch (err) {
        res.status(500).send(err);
    }

}

exports.delete = async (req, res) => {
    try {
        let employees = await Repository.delete(req.params.id);
        res.status(200).json(employees);

    } catch (err) {
        res.status(500).send(err);
    }
}

exports.getMentorByMentor = async (req, res) => {

        try {
            await Repository.updateSchedule(
                req.params.id, {
                    scheduled: true,
                });
    
            var employees = await Repository.getById(req.params.id);
                console.log(employees)
            res.status(200).json({
                register: employees.register,
                name: employees.name,
                mentor: employees.mentor,
                skills: employees.skills,
                boticoin: employees.boticoin,
                scheduled: employees.scheduled
            });
        } catch (err) {
            res.status(500).send(err);
            console.log(err)
        }
    
} 