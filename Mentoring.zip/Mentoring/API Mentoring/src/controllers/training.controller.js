'use strict';
const Model = require('../models/training'),
    Training = Model.Training,
    Repository = require("../repositories/training.repository");;


exports.getAll = async (req, res) => {

    try {
        var data = await Repository.get();

        res.status(200).json(data);

    } catch (err) {
        res.status(500).send({
            message: 'Falha ao processar aquisição',
            err
        });
    }
}

exports.getById = async (req, res) => {
    try {
        var training = await Repository.getById(req.params.id);
        if (training)
            res.status(200).json({
                _id: training._id,
                register: training.register,
                name: training.name,
                mentor: training.mentor,
                skills: training.skills,
                createDate: training.createDate,
                boticoin: training.boticoin
            });
        else
            res.status(200).send("Nenhum consultor foi localizado");

    } catch (err) {
        res.status(500).send("Erro ao tentar obter consultor por id");
    }
}

exports.create = async (req, res) => {
    try {

        let newTraining = {
            whoWish: req.body.whoWish,
            mentor: req.body.mentor,
            accepted: req.body.accepted,
            reason: req.body.reason,
        };

        var training = await Repository.create(newTraining);

        res.status(200).json(training);

    } catch (err) {
        res.status(500).send(err);
    }
}

exports.update = async (req, res) => {
    try {
        await Repository.update(
            req.params.id, {
                accepted: req.body.accepted,
                reason: req.body.reason,
            });

        var training = await Repository.getById(req.params.id);

        res.status(200).json({
            whoWish: training.whoWish,
            mentor: training.mentor,
            accepted: training.accepted,
            reason: training.reason,
        });
    } catch (err) {
        res.status(500).send(err);
    }

}

exports.delete = async (req, res) => {
    try {
        let training = await Repository.delete(req.params.id);
        res.status(200).json(training);

    } catch (err) {
        res.status(500).send(err);
    }
}